from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

out = '/mnt/data/iot_integrador/Informe_Smart_Greenhouse_Lab.docx'

def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tcPr.append(shd)

def set_cell_text(cell, text, bold=False):
    cell.text = ''
    p = cell.paragraphs[0]
    run = p.add_run(text)
    run.bold = bold
    run.font.size = Pt(9)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


doc = Document()
section = doc.sections[0]
section.top_margin = Inches(0.55)
section.bottom_margin = Inches(0.55)
section.left_margin = Inches(0.65)
section.right_margin = Inches(0.65)

styles = doc.styles
styles['Normal'].font.name = 'Arial'
styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Arial')
styles['Normal'].font.size = Pt(9)
for s in ['Heading 1','Heading 2']:
    styles[s].font.name = 'Arial'
    styles[s]._element.rPr.rFonts.set(qn('w:eastAsia'), 'Arial')

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Proyecto Integrador - Computación Física e Internet de las Cosas')
r.bold = True
r.font.size = Pt(14)
r.font.name = 'Arial'

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Smart Greenhouse Lab: IoT Dashboard para Monitoreo Ambiental y de Movimiento')
r.bold = True
r.font.size = Pt(12)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Dashboard Streamlit conectado a InfluxDB para variables DHT22 y MPU6050')
r.italic = True
r.font.size = Pt(9)

h = doc.add_heading('1. Descripción del caso de uso y narrativa del proyecto', level=1)
h.runs[0].font.size = Pt(11)
doc.add_paragraph(
    'Smart Greenhouse Lab es una solución IoT orientada al monitoreo de una estación experimental de cultivo o prototipo de invernadero académico. El sistema permite observar, en una interfaz web, las condiciones ambientales del entorno y el comportamiento físico del módulo. El sensor DHT22 suministra temperatura y humedad, mientras que el MPU6050 registra aceleración y giro para detectar manipulación, vibraciones o movimientos anómalos.'
)
doc.add_paragraph(
    'La propuesta responde a un reto real de diseño interactivo: convertir datos técnicos de sensores en información comprensible para un usuario no experto. Por ello, el tablero prioriza indicadores visuales, alertas de estado y gráficas temporales que facilitan decisiones rápidas, como ventilar el espacio, revisar humedad o verificar si el módulo fue golpeado.'
)

h = doc.add_heading('2. Arquitectura del sistema', level=1)
h.runs[0].font.size = Pt(11)

table = doc.add_table(rows=1, cols=5)
table.alignment = WD_TABLE_ALIGNMENT.CENTER
table.style = 'Table Grid'
labels = ['Sensores físicos', 'Microcontrolador', 'Base de datos', 'Consulta', 'Interfaz']
for i, label in enumerate(labels):
    set_cell_text(table.rows[0].cells[i], label, True)
    set_cell_shading(table.rows[0].cells[i], 'D9EAD3')
row = table.add_row().cells
items = ['DHT22\nTemperatura\nHumedad', 'ESP32 / Arduino\nPublicación de telemetría', 'InfluxDB Cloud\nBucket: iot_telemetry_data', 'Python + Flux\nInfluxDB Client', 'Streamlit\nDashboard y alertas']
for i, item in enumerate(items):
    set_cell_text(row[i], item)

p = doc.add_paragraph()
p.add_run('Flujo lógico: ').bold = True
p.add_run('sensor -> ESP32 -> InfluxDB Cloud -> consulta Flux en Python -> procesamiento en Pandas -> visualización en Streamlit.')

doc.add_paragraph(
    'La base de datos se organiza en dos mediciones: environment, con los campos temperature y humidity; y mpu6050, con accel_x, accel_y, accel_z, gyro_x, gyro_y y gyro_z. Esta estructura permite separar las variables ambientales de las variables cinemáticas y construir visualizaciones independientes o combinadas.'
)

h = doc.add_heading('3. Flujo de datos y funciones principales', level=1)
h.runs[0].font.size = Pt(11)

bullets = [
    'Captura: el DHT22 mide temperatura y humedad; el MPU6050 registra aceleración y velocidad angular.',
    'Almacenamiento: las lecturas se envían a InfluxDB como series de tiempo, conservando el instante de registro.',
    'Consulta: Streamlit ejecuta consultas Flux sobre una ventana configurable de 5 a 180 minutos.',
    'Procesamiento: el dashboard calcula magnitud de aceleración y magnitud giroscópica para interpretar movimiento general.',
    'Visualización: se presentan métricas, alertas, cuatro gráficas principales y una tabla de lecturas recientes.',
]
for b in bullets:
    doc.add_paragraph(b, style='List Bullet')

h = doc.add_heading('4. Diseño de interfaz y experiencia de usuario', level=1)
h.runs[0].font.size = Pt(11)
doc.add_paragraph(
    'La interfaz fue diseñada con una lógica de lectura rápida: primero se presenta el estado general del sistema mediante indicadores clave; luego se muestran alertas interpretativas; finalmente, se profundiza en las gráficas históricas. La estética utiliza una línea visual asociada al caso de uso ambiental, con tonos verdes, tarjetas suaves y etiquetas claras.'
)

table2 = doc.add_table(rows=1, cols=3)
table2.style = 'Table Grid'
headers = ['Componente', 'Propósito', 'Criterio de interpretación']
for i, htxt in enumerate(headers):
    set_cell_text(table2.rows[0].cells[i], htxt, True)
    set_cell_shading(table2.rows[0].cells[i], 'D9EAD3')
data = [
    ['Métricas superiores', 'Lectura inmediata del estado actual', 'Valor más reciente y cambio frente a lectura anterior'],
    ['Alertas', 'Traducción del dato técnico a acción', 'Temperatura alta, humedad fuera de rango o movimiento detectado'],
    ['Gráficas temporales', 'Análisis de tendencia', 'Evolución de variables en la ventana seleccionada'],
    ['Tabla reciente', 'Verificación técnica', 'Revisión de registros sincronizados por tiempo'],
]
for rowdata in data:
    cells = table2.add_row().cells
    for i, val in enumerate(rowdata):
        set_cell_text(cells[i], val)

h = doc.add_heading('5. Justificación del valor del sistema', level=1)
h.runs[0].font.size = Pt(11)
doc.add_paragraph(
    'El valor del proyecto está en integrar computación física, almacenamiento de series temporales e interfaz web para construir un prototipo funcional y comprensible. A nivel técnico, demuestra la conexión entre hardware IoT, InfluxDB y Streamlit. A nivel de diseño, evidencia cómo los datos pueden convertirse en una experiencia de monitoreo útil, clara y accionable.'
)

doc.add_paragraph(
    'Como mejora futura, el sistema podría incorporar control automático de actuadores, notificaciones remotas, autenticación de usuarios y comparación de rangos ideales según tipo de cultivo.'
)

# Reduce spacing
for para in doc.paragraphs:
    para.paragraph_format.space_after = Pt(3)
    para.paragraph_format.line_spacing = 1.0

for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            for para in cell.paragraphs:
                para.paragraph_format.space_after = Pt(0)

doc.save(out)
print(out)
